
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/trpc-proxy.mts
var BACKEND_URL = "https://yochillsaas.lat";
var trpc_proxy_default = async (req, context) => {
  const CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization"
  };
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  const url = new URL(req.url);
  const targetUrl = `${BACKEND_URL}${url.pathname}${url.search}`;
  try {
    const headers = {};
    for (const [key, value] of req.headers.entries()) {
      if (["content-type", "authorization", "accept"].includes(key.toLowerCase())) {
        headers[key] = value;
      }
    }
    const fetchOptions = {
      method: req.method,
      headers
    };
    if (req.method === "POST" || req.method === "PUT") {
      fetchOptions.body = await req.text();
    }
    const response = await fetch(targetUrl, fetchOptions);
    const body = await response.text();
    return new Response(body, {
      status: response.status,
      headers: {
        ...CORS_HEADERS,
        "Content-Type": response.headers.get("Content-Type") || "application/json"
      }
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: "Proxy error: " + err.message }), {
      status: 502,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
    });
  }
};
var config = {
  path: "/api/trpc/*"
};
export {
  config,
  trpc_proxy_default as default
};
