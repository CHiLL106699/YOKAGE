
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auth.mts
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import pg from "pg";
var JWT_SECRET = process.env.JWT_SECRET || "yokage-jwt-secret-2026-imei";
var DATABASE_URL = process.env.DATABASE_URL || "";
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: CORS_HEADERS });
}
async function getDbClient() {
  const client = new pg.Client({ connectionString: DATABASE_URL, ssl: { rejectUnauthorized: false } });
  await client.connect();
  return client;
}
async function handleLogin(body) {
  const { username, password } = body || {};
  if (!username || !password) {
    return jsonResponse({ error: "\u8ACB\u8F38\u5165\u5E33\u865F\u548C\u5BC6\u78BC" }, 400);
  }
  let client;
  try {
    client = await getDbClient();
    const result = await client.query(
      `SELECT sa.id as account_id, sa.username, sa.password_hash, sa.role,
              s.id as staff_id, s.name as staff_name, s.organization_id as tenant_id,
              t.name as tenant_name, t.slug as tenant_slug
       FROM staff_accounts sa
       LEFT JOIN staff s ON sa.staff_id = s.id
       LEFT JOIN tenants t ON s.organization_id = t.id
       WHERE sa.username = $1 AND sa.is_active = true`,
      [username]
    );
    if (result.rows.length === 0) {
      return jsonResponse({ error: "\u5E33\u865F\u4E0D\u5B58\u5728\u6216\u5DF2\u505C\u7528" }, 401);
    }
    const account = result.rows[0];
    const isValid = await bcrypt.compare(password, account.password_hash);
    if (!isValid) {
      return jsonResponse({ error: "\u5BC6\u78BC\u932F\u8AA4" }, 401);
    }
    const tokenPayload = {
      staffId: account.staff_id,
      accountId: account.account_id,
      role: account.role,
      organizationId: account.tenant_id,
      tenantSlug: account.tenant_slug,
      name: account.staff_name
    };
    const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: "7d" });
    return jsonResponse({
      success: true,
      token,
      user: {
        id: account.staff_id,
        name: account.staff_name,
        role: account.role,
        organizationId: account.tenant_id,
        tenantName: account.tenant_name,
        tenantSlug: account.tenant_slug
      }
    });
  } catch (err) {
    console.error("Login error:", err);
    return jsonResponse({ error: "\u4F3A\u670D\u5668\u932F\u8AA4: " + err.message }, 500);
  } finally {
    if (client) await client.end();
  }
}
async function handleMe(authHeader) {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return jsonResponse({ user: null });
  }
  try {
    const token = authHeader.replace("Bearer ", "");
    const decoded = jwt.verify(token, JWT_SECRET);
    return jsonResponse({
      user: {
        id: decoded.staffId,
        name: decoded.name,
        role: decoded.role,
        organizationId: decoded.organizationId,
        tenantSlug: decoded.tenantSlug
      }
    });
  } catch {
    return jsonResponse({ user: null });
  }
}
var auth_default = async (req, context) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/api\/auth\/?/, "").replace(/\/$/, "");
  if (req.method === "POST" && (path === "login" || path === "")) {
    const body = await req.json().catch(() => null);
    return handleLogin(body);
  }
  if (req.method === "GET" && path === "me") {
    return handleMe(req.headers.get("Authorization"));
  }
  if (req.method === "POST" && path === "logout") {
    return jsonResponse({ success: true });
  }
  return jsonResponse({ error: "Not found" }, 404);
};
var config = {
  path: "/api/auth/*"
};
export {
  config,
  auth_default as default
};
